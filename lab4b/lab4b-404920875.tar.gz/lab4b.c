/*
NAME: Erica Xie
EMAIL: ericaxie@ucla.edu
ID: 404920875 
*/

#include <stdio.h> 
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h> 
#include <math.h> 
#include <signal.h>
#include <mraa.h> 
#include <time.h> 
#include <sys/resource.h> 
#include <poll.h> 

int run = 1; //run flag 
int l = 0; //log flag
int fd1 = 1; 
char buf[2048]; 
float temp = 0; 
time_t curtime; 
struct tm *info; 
int hour = 0; 
int min = 0; 
int sec = 0; 

void interrupt() {

    /* find current time */
    time(&curtime); 
    info = localtime(&curtime); 
    hour = info->tm_hour; 
    min = info->tm_min; 
    sec = info->tm_sec; 

    sprintf(buf, "%.2d:%.2d:%.2d SHUTDOWN\n", hour, min, sec);
    if(l) {
        if(write(fd1, &buf, strlen(buf)) < 0) {
            fprintf(stderr, "Write error: %s\n", strerror(errno)); 
            fflush(stderr); 
            exit(1);
        }
    }
    if(write(1, &buf, strlen(buf)) < 0) {
        fprintf(stderr, "Write error: %s\n", strerror(errno));
        fflush(stderr); 
        exit(1);
    }

    memset(buf, 0, 2048);
    run = 0; 

}

int main(int argc, char *argv[])
{
    /* declare all variables */
    char ibuf[2048], cbuf[2048], pbuf[2048], c; 
    int a, n, k, opt, p, f, input, output, ret, count, stopped;
    float r; 
    mraa_gpio_context button; 
    mraa_aio_context temp_sensor; 
    struct pollfd fds[1];

    static struct option long_options[] =
    {
        {"period", required_argument, NULL, 'p'},
        {"scale", required_argument, NULL, 's'},
        {"log", required_argument, NULL, 'l'},
        {0, 0, 0, 0}
    }; 

    struct rlimit lim = {
        10000,  /* Soft limit */
        10000  /* Hard limit (ceiling for rlim_cur) */
    };
  
    /* initialize variables */
    a = 0; 
    n = 0; 
    p = 1; 
    k = 0;
    f = 1; 
    r = 0; 
    count = 0; 
    stopped = 0; 
  
    /* check optional arguments */
    if(argc > 1) {
        while((opt = getopt_long(argc, argv, "psl:", long_options, NULL)) != -1) {
            switch(opt) {
            case 'p':
                p = atoi(optarg); 
                break; 
            case 's':
                if(strcmp("F", optarg) == 0) 
                    f = 1; 
                else if(strcmp("C", optarg) == 0) 
                    f = 0; 
                else {
                    fprintf(stderr, "Invalid Input to Scale\n");
                    fflush(stderr); 
                    exit(1);
                }
                break;
            case 'l':
                l = 1;
                setrlimit(RLIMIT_FSIZE, &lim); 
                output = creat(optarg, 0644); 
                if (output < 0) {
                    fprintf(stderr, "Cannot create file: %s given by --output\n%s\n", optarg, strerror(errno));
                    exit(1);
                }
                fd1 = open(optarg, O_WRONLY);
                if (fd1 < 0) {
                    fprintf(stderr, "Cannot open file: %s given by --log\n%s\n", optarg, strerror(errno));
                    fflush(stderr); 
                    exit(1);
                }
                break;
            default:
                fprintf(stderr, "Invalid Argument\n");
                fflush(stderr); 
                exit(1);
                break; 
            }
        }
    }

    /* initialize button */
    button = mraa_gpio_init(60); 
    if (button == NULL) { 
        fprintf(stderr, "Failed to initialize GPIO\n");
        mraa_deinit();
        fflush(stderr); 
        exit(1);
    }  
    if(mraa_gpio_dir(button, MRAA_GPIO_IN) != MRAA_SUCCESS) {
        fprintf(stderr, "Error directing input\n"); 
        fflush(stderr); 
        exit(1);
    }
    if(mraa_gpio_isr(button, MRAA_GPIO_EDGE_RISING, &interrupt, NULL) != MRAA_SUCCESS) {
        fprintf(stderr, "Error setting interrupt\n");
        fflush(stderr); 
        exit(1);
    } 

    /* initialize temp */
    temp_sensor = mraa_aio_init(1); 
    if (temp_sensor == NULL) { 
        fprintf(stderr, "Failed to initialize AIO\n");
        mraa_deinit();
        fflush(stderr); 
        exit(1);
    }  

    fds[0].fd = 0; 
    fds[0].events = POLLIN | POLLHUP | POLLERR; 

    while(run) {

        ret = poll(fds, 1, 0);
        if(ret > 0) {
            /* check each of the 3 events */ 
            if (fds[0].revents & POLLIN) { 
                memset(ibuf, 0, 2048);
                input = read (0, ibuf, 4000); 
                if(input < 0) {
                    fprintf(stderr, "Read error: %s\n", strerror(errno));
                    fflush(stderr);
                    exit(1);
                }
                for (n = 0; n < input; n++) {
                    c = ibuf[n]; 
                    cbuf[count] = c; 
                    count++; 
                    /* <lf> */
                    if (c == '\n') { 
                        /* find which command and execute */
                        if(strncmp("SCALE=F\n", cbuf, 8) == 0) 
                            f = 1; 
                        else if(strncmp("SCALE=C\n", cbuf, 8) == 0) 
                            f = 0; 
                        else if(strncmp("PERIOD=", cbuf, 7) == 0) {  
                            int i = 0; 
                            if(count > 8) {
                                for(k = 7; k < count; k++) { 
                                    if(cbuf[k] != '\n') {
                                        pbuf[i] = cbuf[k]; 
                                        i++;
                                    } 
                                } 
                                int new_period = atoi(pbuf); 
                                if(new_period > 0)
                                    p = new_period;  
                            } 
                        }
                        else if(strncmp("STOP\n", cbuf, 5) == 0) 
                            stopped = 1; 
                        else if(strncmp("START\n", cbuf, 6) == 0) 
                            stopped = 0; 
                        else if(strncmp("OFF\n", cbuf, 4) == 0) 
                            interrupt(); 
                        /* write command to log */
                        if(l) {
                            if(write(fd1, cbuf, count) < 0) {
                                fprintf(stderr, "Write error: %s\n", strerror(errno)); 
                                fflush(stderr); 
                                exit(1);
                            }
                        }
                        /* reset for next command */ 
                        memset(cbuf, 0, 2048);
                        count = 0; 
                    }
                }
            }
            if (fds[0].revents & POLLHUP) {
              fprintf(stderr, "POLLHUP\n");
              exit(0);
            }
            if (fds[0].revents & POLLERR) {
              fprintf(stderr, "POLLERR\n");
              exit(1);
            }
        } 
        else if (ret < 0) {
          fprintf(stderr, "Poll command failed\n");
          exit(1);
        }

        /* find current time */
        time(&curtime); 
        info = localtime(&curtime); 
        hour = info->tm_hour; 
        min = info->tm_min; 
        sec = info->tm_sec; 

        /* find temp */
        a = mraa_aio_read(temp_sensor); 
        r = 1023.0/a - 1.0; 
        r = 100000 * r; 
        temp = 1.0/(log(r/100000)/4275 + 1/298.15) - 273.15; //celsius 
        if(f) { //fahrenheit 
            temp = temp*9/5 + 32; 
        }

        /* report */ 
        if(run && !stopped) {
            sprintf(buf, "%.2d:%.2d:%.2d %0.1f\n", hour, min, sec, temp);
            if(l) {
                if(write(fd1, &buf, strlen(buf)) < 0) {
                    fprintf(stderr, "Write error: %s\n", strerror(errno)); 
                    fflush(stderr); 
                    exit(1);
                }
            }
            if(write(1, &buf, strlen(buf)) < 0) {
                fprintf(stderr, "Write error: %s\n", strerror(errno)); 
                fflush(stderr); 
                exit(1);
            }
        }

        memset(buf, 0, 2048);
        sleep(p);

    } 

    if(mraa_gpio_close(button) != MRAA_SUCCESS) {
        fprintf(stderr, "Error closing button\n"); 
        fflush(stderr); 
        exit(1);
    }
    if(mraa_aio_close(temp_sensor) != MRAA_SUCCESS) {
        fprintf(stderr, "Error closing temp_sensor\n"); 
        fflush(stderr); 
        exit(1);
    }

    exit(0); 
    
}

/*

Links: 
http://wiki.seeedstudio.com/Grove-Temperature_Sensor_V1.2/ 
https://www.tutorialspoint.com/c_standard_library/c_function_localtime.htm
https://drive.google.com/drive/folders/0B6dyEb8VXZo-N3hVcVI0UFpWSVk 
https://iotdk.intel.com/docs/master/mraa/
http://man7.org/linux/man-pages/man3/fflush.3.html
http://man7.org/linux/man-pages/man2/open.2.html


*/
