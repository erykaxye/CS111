#!/usr/bin/python

#NAME: Erica Xie, Michelle Lam
#EMAIL: ericaxie@ucla.edu, laammichelle@gmail.com
#ID: 404920875, 404926523

import os
os.symlink('lab3b.py', 'lab3b')
print "Successfully created link"
